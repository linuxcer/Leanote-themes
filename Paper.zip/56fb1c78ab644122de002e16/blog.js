var LEAUI_NAV = {
	to: function(iframe, toTop) { 
	    if(LEA.isMobile) {
			toTop -= 55;
		}
		var top = toTop;
		var nowTop = iframe.scrollTop();
			
		// iframe.scrollTop(top);
		// $(iframe).animate({scrollTop: top}, 300); // 有问题
		
		var d = 200; // 时间间隔
		for(var i = 0; i < d; i++) {
			setTimeout(
			(function(top) {
				return function() {
					iframe.scrollTop(top);
				}
			})(nowTop + 1.0*i*(top-nowTop)/d), i);
		}
		// 最后必然执行
		setTimeout(function() {
			iframe.scrollTop(top);
		}, d+5);
		return;
	},
	scrollTo: function(self0, tagName) {
		var self = this;

		var encodeText = $(self0).data('text');
		var text = decodeURI(encodeText);

		var iframe = $("#content");
		var target = iframe.find(tagName + ":contains(" + text + ")");
		// 找到是第几个
		// 在nav是第几个
		var navs = $('#blogNavContent [data-a="' + tagName + '-' + encodeText + '"]');
		var len = navs.size();
		for(var i = 0; i < len; ++i) {
			if(navs[i] == self0) {
				break;
			}
		}
		if (target.size() >= i+1) {
			target = target.eq(i);
			// 之前插入, 防止多行定位不准
			var top = target.offset().top;

			self.to($('body'), top);
		}
	}
};

var preBody = "";
function genNav() {
    var $con = $("#content");
    var html = $con.html();
    if (preBody == html) {
        return;
    }
    preBody = html;

    // build to a tree
    var tree = {
        children: []
    }; //[{title: "xx", level:1, children:[{}]}, {level: 1, title:"xx2"}];
    var hs = $con.find("h1,h2,h3,h4,h5,h6").toArray();

    // parents
    var last = [tree, null, null, null, null, null, null, null];

    // find parent(if not build it)
    function findP(cur) {
        var level = cur.level;
        if (last[level - 1]) {
            return last[level - 1];
        }
        // build last
        for (var i = 1; i < level; i++) {
            if (last[i] == null) {
                var node = {
                    text: "",
                    level: i,
                    children: []
                };
                last[i - 1].children.push(node);
                last[i] = node;
            }
        }
        return last[level - 1];
    }
    
    // 形成一棵树
    // push to tree
    function addToTree(cur) {
        // 找到其上级
        var p = findP(cur);
        // 插入到它的子结点中
        p.children.push(cur);
        last[cur.level] = cur;
        // clear the later last
        for (var i = cur.level + 1; i <= 6; i++) {
            last[i] = null;
        }
    }
    
    // 
    function treeToHtml(cur) {
        var encodeText = encodeURI(cur.text);
        var html = '<li class="nav-h' + cur.level + '"><a href="javascript:;" data-text="' + encodeText + '" data-a="h' + cur.level + '-' + encodeText + '" onclick="LEAUI_NAV.scrollTo(this, \'h' + cur.level + '\')">' + cur.text + '</a>';
        if (cur.children.length) {
            html += "<ul>";
            for (var i = 0; i < cur.children.length; ++i) {
                html += treeToHtml(cur.children[i]);
            }
            html += "</ul>";
        }
        html += "</li>";
        return html;
    }
    function toHtml() {
        var html = "";
        
        if (tree.children.length) {
            // 如果leve1没有, 则去掉
            if(tree.children.length == 1) {
                tree = tree.children[0];
            }
            
            html += "<ul>";
            for (var i = 0; i < tree.children.length; ++i) {
                html += treeToHtml(tree.children[i]);
            }
            html += "</ul>";
        }
        return html;
    }

    // build to a tree
    for (var i = 0; i < hs.length; ++i) {
        var text = $(hs[i]).text();
        var tagName = hs[i].tagName;
        var level = +tagName.substr(1);

        var cur = {
            text: text,
            level: level,
            children: []
        };
        addToTree(cur);
    }

    $("#blogNavContent").html(toHtml()); // auto
}

function initNav() {
	genNav();
	
	$("#blogNav").show();
	$("#blogNavContent").show();
	
// 	$("#blogNavNav").click(function() {
// 		var $o = $("#blogNavContent");
// 		if($o.is(":hidden")) {
// 			$o.show();
// 		} else {
// 			$o.hide();
// 		}
// 	});
}