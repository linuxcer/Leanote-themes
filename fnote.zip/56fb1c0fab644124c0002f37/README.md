# leanote的fexo主题


本主题根据[hexo-fexo](https://github.com/forsigner/fexo)主题进行移植，感谢@forsigner。

使用了[K-article](https://github.com/Kinice/K-article)优化markdown效果，感谢@Kinice

效果图：

预览: http://svtter.leanote.com

## Tips


## 尚有不完善

- [ ] baidu_analytics
- [ ] disqus，评论支持
